<?php get_header(); 

	get_template_part('templates/content', 'singleportfolio');
				
				get_sidebar(); ?>
      		</div><!-- /.row-->
    	</div><!-- /.content -->
  	</div><!-- /.wrap -->
  	<?php get_footer(); ?>